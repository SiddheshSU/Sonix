// Helper to decode base64 to Uint8Array
function decode(base64: string) {
  if (!base64) return new Uint8Array(0);
  try {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  } catch (e) {
    console.error("Base64 decoding failed", e);
    return new Uint8Array(0);
  }
}

// Helper to convert raw PCM16 to AudioBuffer
async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  // Safety check for empty or malformed data
  if (!data || data.length === 0) {
    // Return a silent 1-frame buffer to avoid API crash
    return ctx.createBuffer(numChannels, 1, sampleRate);
  }

  // Gemini returns raw PCM16 (2 bytes per sample).
  // Ensure we use the correct buffer view and handle potential byte alignment issues.
  const usableByteLength = data.byteLength - (data.byteLength % 2);
  const dataInt16 = new Int16Array(data.buffer, data.byteOffset, usableByteLength / 2);
  
  const frameCount = dataInt16.length / numChannels;
  
  // Guard against 0 frameCount which causes createBuffer to throw
  const safeFrameCount = Math.max(1, frameCount);
  const buffer = ctx.createBuffer(numChannels, safeFrameCount, sampleRate);

  if (frameCount > 0) {
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        // Convert PCM16 (-32768 to 32767) to Float32 (-1.0 to 1.0)
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
  }
  
  return buffer;
}

export const playRawAudio = async (base64String: string, playbackRate: number = 1.0) => {
  if (!base64String) {
    console.warn("playRawAudio called with empty string");
    return;
  }

  const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
  const audioContext = new AudioContextClass({ sampleRate: 24000 });
  
  try {
    const bytes = decode(base64String);
    if (bytes.length === 0) return;

    const buffer = await decodeAudioData(bytes, audioContext, 24000, 1);
    
    const source = audioContext.createBufferSource();
    source.buffer = buffer;
    source.playbackRate.value = playbackRate;
    source.connect(audioContext.destination);
    
    // Ensure the context is running (browsers often suspend it until user interaction)
    if (audioContext.state === 'suspended') {
      await audioContext.resume();
    }
    
    source.start();
  } catch (e) {
    console.error("Audio playback failed", e);
    throw e;
  }
};