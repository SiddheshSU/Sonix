
// Simple synth sound generator for UI feedback
let audioCtx: AudioContext | null = null;

const getContext = () => {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  return audioCtx;
};

export const playSound = (type: 'start' | 'stop' | 'success' | 'error') => {
  const ctx = getContext();
  if (ctx.state === 'suspended') {
    ctx.resume();
  }

  const now = ctx.currentTime;

  switch (type) {
    case 'start':
      // "Assistant Wake" sound - Two distinct tones (Boop-Bip)
      // Tone 1: Lower Pitch
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.frequency.setValueAtTime(660, now); // E5
      osc1.type = 'sine';
      gain1.gain.setValueAtTime(0.08, now);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
      osc1.start(now);
      osc1.stop(now + 0.15);

      // Tone 2: Higher Pitch (shortly after)
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.frequency.setValueAtTime(880, now + 0.12); // A5
      osc2.type = 'sine';
      gain2.gain.setValueAtTime(0.08, now + 0.12);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.27);
      osc2.start(now + 0.12);
      osc2.stop(now + 0.27);
      break;

    case 'stop':
      // Power down latch (Square wave sweeping down)
      const oscStop = ctx.createOscillator();
      const gainStop = ctx.createGain();
      oscStop.connect(gainStop);
      gainStop.connect(ctx.destination);
      
      oscStop.type = 'square';
      oscStop.frequency.setValueAtTime(400, now);
      oscStop.frequency.exponentialRampToValueAtTime(100, now + 0.15);
      
      gainStop.gain.setValueAtTime(0.05, now);
      gainStop.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
      
      oscStop.start(now);
      oscStop.stop(now + 0.15);
      break;

    case 'success':
      // "Data Acquired" Arpeggio (Sawtooth)
      const oscSucc = ctx.createOscillator();
      const gainSucc = ctx.createGain();
      oscSucc.connect(gainSucc);
      gainSucc.connect(ctx.destination);

      oscSucc.type = 'sawtooth';
      
      // Fast arpeggio effect
      oscSucc.frequency.setValueAtTime(440, now); // A4
      oscSucc.frequency.setValueAtTime(554.37, now + 0.08); // C#5
      oscSucc.frequency.setValueAtTime(659.25, now + 0.16); // E5
      
      // Smooth decay
      gainSucc.gain.setValueAtTime(0.05, now);
      gainSucc.gain.setValueAtTime(0.05, now + 0.2);
      gainSucc.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
      
      oscSucc.start(now);
      oscSucc.stop(now + 0.6);
      break;

    case 'error':
      // Glitch/Buzz
      const oscErr = ctx.createOscillator();
      const gainErr = ctx.createGain();
      oscErr.connect(gainErr);
      gainErr.connect(ctx.destination);

      oscErr.type = 'sawtooth';
      oscErr.frequency.setValueAtTime(110, now);
      oscErr.frequency.linearRampToValueAtTime(100, now + 0.3);
      
      gainErr.gain.setValueAtTime(0.1, now);
      gainErr.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
      
      oscErr.start(now);
      oscErr.stop(now + 0.3);
      break;
  }
};