import { GoogleGenAI, Type, Modality } from "@google/genai";
import { AnalysisResult, TranslationResult } from "../types";

const apiKey = process.env.API_KEY;

// Use gemini-3-flash-preview for multimodal generateContent tasks like audio analysis
const ANALYSIS_MODEL = "gemini-3-flash-preview";
const TTS_MODEL = "gemini-2.5-flash-preview-tts";

export const analyzeAudioForensics = async (
  base64Audio: string,
  mimeType: string
): Promise<AnalysisResult> => {
  if (!apiKey) throw new Error("API Key missing");
  const ai = new GoogleGenAI({ apiKey });

  const prompt = `
    Analyze the provided audio for SCAM DETECTION and forensic integrity.
    
    1. Authenticity: Is it a Human voice or an AI-generated Deepfake?
    2. Scam Detection: Evaluate if this is a fraudulent call (e.g., impersonation, bank scam, tech support fraud, kidnapping scam).
    3. Safety Score: Calculate a Safety Percentage (0-100).
    4. Safety Accuracy: Provide a confidence/accuracy score (0-100) for your calculated Safety Percentage.
    5. Actionable Advice: If risk is detected (Safety < 70%), provide 2-3 specific "Tactical Advice" steps for the user to stay safe.
    6. Voice Level & Quality: Analyze decibel dynamics and audio fidelity.

    Return the result in JSON format only:
    {
      "verdict": "AI GENERATED" | "HUMAN VERIFIED" | "UNCERTAIN",
      "confidence": 0-100,
      "riskLevel": "LOW" | "MEDIUM" | "HIGH" | "CRITICAL",
      "safetyPercentage": 0-100,
      "safetyAccuracy": 0-100,
      "isSpam": boolean,
      "fraudType": "string",
      "scamAdvice": "Detailed advice for the user if it is a scam",
      "timestamp": "ISO Date String",
      "details": ["string"],
      "voiceAnalysis": {
        "level": "string",
        "quality": "string",
        "description": "Brief summary of voice characteristics"
      },
      "messageDecoding": {
        "language": "string",
        "sentiment": "string",
        "intent": "string",
        "keyWording": ["string"],
        "riskReasoning": "string",
        "extractedFunction": "string"
      },
      "technicalMetrics": {
        "spectralInconsistency": "string",
        "backgroundNoiseLevel": "string",
        "breathPatternAnalysis": "string"
      }
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: ANALYSIS_MODEL,
      contents: {
        parts: [
          { inlineData: { mimeType, data: base64Audio } },
          { text: prompt }
        ],
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            verdict: { type: Type.STRING },
            confidence: { type: Type.NUMBER },
            riskLevel: { type: Type.STRING },
            safetyPercentage: { type: Type.NUMBER },
            safetyAccuracy: { type: Type.NUMBER },
            isSpam: { type: Type.BOOLEAN },
            fraudType: { type: Type.STRING },
            scamAdvice: { type: Type.STRING },
            timestamp: { type: Type.STRING },
            details: { type: Type.ARRAY, items: { type: Type.STRING } },
            voiceAnalysis: {
              type: Type.OBJECT,
              properties: {
                level: { type: Type.STRING },
                quality: { type: Type.STRING },
                description: { type: Type.STRING }
              }
            },
            messageDecoding: {
              type: Type.OBJECT,
              properties: {
                language: { type: Type.STRING },
                sentiment: { type: Type.STRING },
                intent: { type: Type.STRING },
                keyWording: { type: Type.ARRAY, items: { type: Type.STRING } },
                riskReasoning: { type: Type.STRING },
                extractedFunction: { type: Type.STRING }
              }
            },
            technicalMetrics: {
              type: Type.OBJECT,
              properties: {
                spectralInconsistency: { type: Type.STRING },
                backgroundNoiseLevel: { type: Type.STRING },
                breathPatternAnalysis: { type: Type.STRING }
              }
            }
          }
        }
      },
    });

    const text = response.text || "{}";
    return JSON.parse(text) as AnalysisResult;
  } catch (error) {
    console.error("Forensics Error:", error);
    throw error;
  }
};

export const translateAudio = async (
  base64Audio: string,
  mimeType: string,
  targetLanguage: string,
  tone: string = "Neutral"
): Promise<TranslationResult> => {
  if (!apiKey) throw new Error("API Key missing");
  const ai = new GoogleGenAI({ apiKey });

  const prompt = `
    Listen to the audio. 
    1. Transcribe it perfectly.
    2. Translate it into ${targetLanguage} using a ${tone} tone.
    3. Detect original language.
    
    Return JSON: { "originalText": "...", "translatedText": "...", "detectedLanguage": "...", "targetLanguage": "${targetLanguage}" }
  `;

  try {
    const response = await ai.models.generateContent({
      model: ANALYSIS_MODEL,
      contents: {
        parts: [
          { inlineData: { mimeType, data: base64Audio } },
          { text: prompt }
        ],
      },
      config: { responseMimeType: "application/json" },
    });
    const text = response.text || "{}";
    return JSON.parse(text) as TranslationResult;
  } catch (error) {
    console.error("Translation Error:", error);
    throw error;
  }
};

export const translateText = async (
  text: string,
  targetLanguage: string,
  tone: string = "Neutral"
): Promise<TranslationResult> => {
  if (!apiKey) throw new Error("API Key missing");
  const ai = new GoogleGenAI({ apiKey });

  const prompt = `
    Translate the following text into ${targetLanguage} using a ${tone} tone.
    Text: "${text}"
    Return JSON: { "originalText": "${text}", "translatedText": "...", "detectedLanguage": "...", "targetLanguage": "${targetLanguage}" }
  `;

  try {
    const response = await ai.models.generateContent({
      model: ANALYSIS_MODEL,
      contents: prompt,
      config: { responseMimeType: "application/json" },
    });
    const resultText = response.text || "{}";
    return JSON.parse(resultText) as TranslationResult;
  } catch (error) {
    console.error("Text Translation Error:", error);
    throw error;
  }
};

export const synthesizeSpeech = async (
  text: string, 
  voiceName: string = 'Fenrir',
  rate: number = 1.0
): Promise<string> => {
  if (!apiKey) throw new Error("API Key missing");
  const ai = new GoogleGenAI({ apiKey });
  
  // Incorporate rate into the prompt instruction for the TTS model
  const prompt = `Speak at a ${rate}x rate: ${text}`;
  
  const response = await ai.models.generateContent({
    model: TTS_MODEL,
    contents: [{ parts: [{ text: prompt }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: { 
        voiceConfig: { 
          prebuiltVoiceConfig: { 
            voiceName 
          } 
        } 
      },
    },
  });
  return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || "";
};