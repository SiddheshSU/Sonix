import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ShieldCheck, Globe, Activity, Zap, ArrowRight, Target, Cpu, History as HistoryIcon, Trash2, X, Terminal, Clock, ShieldAlert, Power, Loader2 } from 'lucide-react';
import { getHistory, deleteFromHistory, clearHistory } from '../utils/historyStore';
import { HistoryItem } from '../types';
import { playSound } from '../utils/soundEffects';
import { synthesizeSpeech } from '../services/geminiService';
import { playRawAudio } from '../utils/audioPlayer';

const Home: React.FC = () => {
  const [showHistory, setShowHistory] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  
  // Intro State
  const [showIntro, setShowIntro] = useState(false);
  const [introAudio, setIntroAudio] = useState<string | null>(null);
  const [isInitializing, setIsInitializing] = useState(false);

  useEffect(() => {
    if (showHistory) {
      setHistory(getHistory());
    }
  }, [showHistory]);

  useEffect(() => {
    // Check session storage to only show intro once per session
    const hasIntro = sessionStorage.getItem('SONIX_INTRO_DONE');
    if (!hasIntro) {
      setShowIntro(true);
      // Pre-fetch the greeting voice - Using 'Kore' for Alexa-like female assistant voice
      synthesizeSpeech("Hello friend, I am your guider", "Kore")
        .then(audio => setIntroAudio(audio))
        .catch(e => console.error("Voice fetch failed", e));
    }
  }, []);

  const handleInitialize = async () => {
    setIsInitializing(true);
    playSound('start');

    try {
      // Use pre-fetched audio if available, otherwise fetch it now
      const audioToPlay = introAudio || await synthesizeSpeech("Hello friend, I am your guider", "Kore");
      await playRawAudio(audioToPlay);
    } catch (e) {
      console.error("Initialization audio failed", e);
    }

    // Small delay to let the animation play out and audio start
    setTimeout(() => {
      sessionStorage.setItem('SONIX_INTRO_DONE', 'true');
      setShowIntro(false);
      setIsInitializing(false);
    }, 500);
  };

  const handleDelete = (id: string) => {
    deleteFromHistory(id);
    setHistory(getHistory());
    playSound('stop');
  };

  const handleClearAll = () => {
    if (confirm('CONFIRM_LOG_PURGE: Are you sure you want to delete all historical logs?')) {
      clearHistory();
      setHistory([]);
      playSound('error');
    }
  };

  if (showIntro) {
    return (
      <div className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center p-4">
        <div className="absolute inset-0 cyber-grid opacity-20 pointer-events-none"></div>
        <div className="scanline"></div>
        
        <div className="max-w-md w-full glass-panel p-12 border border-[#00ff41]/30 flex flex-col items-center text-center space-y-8 relative overflow-hidden animate-slide-up">
           <div className="absolute top-0 left-0 w-full h-1 bg-[#00ff41]/20">
             <div className="h-full bg-[#00ff41] animate-[loading_2s_ease-in-out_infinite]"></div>
           </div>
           
           <div className="w-16 h-16 bg-[#00ff41]/10 rounded-full flex items-center justify-center border border-[#00ff41]/30 shadow-[0_0_30px_rgba(0,255,65,0.2)]">
             <Zap size={32} className="text-[#00ff41] animate-pulse" />
           </div>
           
           <div className="space-y-2">
             <h1 className="text-3xl font-bold font-display italic text-white tracking-tighter uppercase">
               SONIX<span className="text-[#00ff41]"> // </span>VERTEX
             </h1>
             <p className="text-[10px] font-mono text-gray-500 uppercase tracking-[0.4em]">Secure Environment Access</p>
           </div>
           
           <div className="py-4 space-y-2 w-full">
              <div className="flex justify-between text-[9px] font-mono text-gray-600 uppercase tracking-widest">
                 <span>System_Check</span>
                 <span className="text-[#00ff41]">OK</span>
              </div>
              <div className="flex justify-between text-[9px] font-mono text-gray-600 uppercase tracking-widest">
                 <span>Neural_Link</span>
                 <span className="text-[#00ff41]">STANDBY</span>
              </div>
              <div className="flex justify-between text-[9px] font-mono text-gray-600 uppercase tracking-widest">
                 <span>Audio_Bus</span>
                 <span className="text-[#00ff41]">{introAudio ? 'READY' : 'LOADING...'}</span>
              </div>
           </div>
           
           <button 
             onClick={handleInitialize}
             disabled={isInitializing}
             className="w-full py-4 bg-[#00ff41] text-black font-mono font-bold text-xs uppercase tracking-[0.3em] hover:bg-[#00dd3a] transition-all shadow-[0_0_20px_rgba(0,255,65,0.2)] flex items-center justify-center gap-3 group"
           >
             {isInitializing ? (
               <>
                 <Loader2 size={16} className="animate-spin" /> INITIALIZING...
               </>
             ) : (
               <>
                 <Power size={16} className="group-hover:scale-110 transition-transform" /> INITIALIZE_SYSTEM
               </>
             )}
           </button>
           
           <div className="absolute bottom-2 right-4 text-[8px] font-mono text-[#00ff41]/30 uppercase">
             v.10.2.4_BETA
           </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-[75vh] text-center space-y-16 animate-slide-up">
      
      <div className="relative max-w-5xl mx-auto px-4">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[140%] bg-[#00ff41]/5 blur-[120px] pointer-events-none rounded-full"></div>
        
        <div className="space-y-10 relative z-10">
          <div className="inline-flex items-center gap-3 px-5 py-2 bg-[#00ff41]/5 border border-[#00ff41]/20 rounded-full text-[10px] font-mono font-bold text-[#00ff41] tracking-[0.4em] uppercase">
            <Cpu size={14} className="animate-pulse" /> VERTEX_SYSTEM_ONLINE // V.10.2
          </div>
          
          <div className="space-y-2">
            <h1 className="text-5xl md:text-8xl font-bold text-white font-display tracking-tighter italic uppercase leading-none select-none">
              SONIX<span className="text-[#00ff41] text-glow">.</span>SYS
            </h1>
            <p className="text-[#00ff41]/60 font-mono text-xs tracking-[0.5em] uppercase font-bold">Tactical Intelligence Interface</p>
          </div>
          
          <p className="text-base md:text-lg text-gray-500 max-w-2xl mx-auto font-mono tracking-tight leading-relaxed">
            Neural signal processing for anti-fraud verification and translation. 
            Expose malicious synthetic signals with <span className="text-white">SCAM_DETECTOR</span> or bridge linguistic gaps with <span className="text-white">TRANSLATOR</span>.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center pt-6">
            <Link 
              to="/forensics"
              className="group relative px-12 py-5 bg-[#00ff41] text-black font-bold rounded hover:bg-[#00dd3a] transition-all shadow-[0_0_30px_rgba(0,255,65,0.2)] flex items-center justify-center gap-3 uppercase tracking-widest text-xs font-mono"
            >
              <div className="absolute -top-1 -left-1 w-3 h-3 border-t-2 border-l-2 border-white/20"></div>
              <div className="absolute -bottom-1 -right-1 w-3 h-3 border-b-2 border-r-2 border-white/20"></div>
              SCAM_DETECTION <ShieldAlert size={18} className="group-hover:rotate-12 transition-transform" />
            </Link>
            <button 
              onClick={() => { setShowHistory(!showHistory); playSound('start'); }}
              className="group relative px-12 py-5 bg-white/5 border border-white/10 text-white font-bold rounded hover:bg-white/10 transition-all flex items-center justify-center gap-3 uppercase tracking-widest text-xs font-mono"
            >
              <div className="absolute -top-1 -right-1 w-3 h-3 border-t-2 border-r-2 border-white/20"></div>
              <div className="absolute -bottom-1 -left-1 w-3 h-3 border-b-2 border-l-2 border-white/20"></div>
              {showHistory ? 'CLOSE_LOGS' : 'SYSTEM_HISTORY'} <HistoryIcon size={18} />
            </button>
          </div>
        </div>
      </div>

      {showHistory && (
        <div className="w-full max-w-4xl animate-slide-up space-y-6">
          <div className="flex justify-between items-center border-b border-[#00ff41]/20 pb-4">
            <h2 className="text-xs font-bold text-[#00ff41] font-mono tracking-[0.4em] uppercase flex items-center gap-3">
              <Clock size={16} /> RECENT_SIGNAL_LOGS [MAX_15]
            </h2>
            {history.length > 0 && (
              <button 
                onClick={handleClearAll}
                className="text-[9px] font-mono font-bold text-red-500 hover:text-red-400 transition-colors uppercase tracking-[0.2em] flex items-center gap-2"
              >
                <Trash2 size={12} /> PURGE_ALL_LOGS
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 gap-3">
            {history.length === 0 ? (
              <div className="p-12 glass-panel border-dashed border-[#00ff41]/10 text-gray-700 font-mono text-[10px] uppercase tracking-[0.3em]">
                NO_HISTORICAL_DATA_FOUND // DATABASE_EMPTY
              </div>
            ) : (
              history.map((item) => (
                <div key={item.id} className="glass-panel p-4 flex items-center justify-between border-l-2 border-[#00ff41]/30 hover:border-[#00ff41] transition-all group">
                  <div className="flex items-center gap-6 text-left">
                    <div className={`p-2 rounded bg-white/5 ${item.type === 'DETECTOR' ? 'text-[#00ff41]' : 'text-purple-500'}`}>
                      {item.type === 'DETECTOR' ? <ShieldAlert size={16} /> : <Globe size={16} />}
                    </div>
                    <div>
                      <div className="flex items-center gap-3 mb-1">
                        <span className="text-[10px] font-mono font-bold text-white tracking-widest uppercase">{item.type}</span>
                        <span className="text-[9px] font-mono text-gray-700">{new Date(item.timestamp).toLocaleString()}</span>
                      </div>
                      <p className="text-[11px] text-[#00ff41] font-mono tracking-tight uppercase line-clamp-1 italic">{item.summary}</p>
                      <p className="text-[9px] text-gray-600 font-mono truncate max-w-md">{item.detail}</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => handleDelete(item.id)}
                    className="p-2 text-gray-800 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                    title="DELETE_RECORD"
                  >
                    <X size={16} />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-6xl px-4 pb-24">
        <FeatureCard 
          icon={<ShieldAlert size={24} className="text-[#00ff41]" />}
          title="SCAM_RADAR"
          desc="Advanced neural detection of financial coercion, authority impersonation, and synthetic speech spoofing."
        />
        <FeatureCard 
          icon={<Zap size={24} className="text-[#00ff41]" />}
          title="THREAT_ADVISORY"
          desc="Real-time tactical advice provided by our AI kernel to mitigate risk during active communication intercepts."
        />
        <FeatureCard 
          icon={<Globe size={24} className="text-[#00ff41]" />}
          title="VOX_BRIDGE"
          desc="Context-aware neural translation preserving tonal nuances and emotional subtext across global dialects."
        />
      </div>
    </div>
  );
};

const FeatureCard: React.FC<{ icon: React.ReactNode, title: string, desc: string }> = ({ icon, title, desc }) => (
  <div className="glass-panel p-8 rounded-sm text-left transition-all duration-500 group border-b border-[#00ff41]/10 hover:border-[#00ff41]/50 hover:-translate-y-1">
    <div className="w-12 h-12 rounded bg-[#00ff41]/5 flex items-center justify-center mb-8 border border-[#00ff41]/10 group-hover:bg-[#00ff41]/20 transition-all">
      {icon}
    </div>
    <h3 className="text-xs font-bold text-white mb-4 font-mono tracking-[0.3em] uppercase">{title}</h3>
    <p className="text-gray-600 text-[11px] leading-relaxed font-mono tracking-tight uppercase">{desc}</p>
    <div className="mt-6 flex gap-1">
      <div className="w-2 h-0.5 bg-[#00ff41]/20"></div>
      <div className="w-8 h-0.5 bg-[#00ff41]/40"></div>
    </div>
  </div>
);

export default Home;