import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import AudioInput from '../components/AudioInput';
import { translateAudio, translateText, synthesizeSpeech } from '../services/geminiService';
import { playRawAudio } from '../utils/audioPlayer';
import { TranslationResult } from '../types';
import { Languages, Volume2, Loader2, Globe, Terminal, Settings, User, Type, MessageSquare, Sparkles, Zap, RotateCcw, Play, ArrowRightLeft, Radio, Mic, Activity, Binary, Ear } from 'lucide-react';
import { playSound } from '../utils/soundEffects';
import { saveToHistory } from '../utils/historyStore';

const LANGUAGES = [
  { code: 'en', name: 'English' },
  { code: 'hi', name: 'Hindi' },
  { code: 'ta', name: 'Tamil' },
  { code: 'te', name: 'Telugu' },
  { code: 'ml', name: 'Malayalam' },
  { code: 'th', name: 'Thai' },
  { code: 'fr', name: 'French' },
  { code: 'de', name: 'German' },
  { code: 'ja', name: 'Japanese' },
  { code: 'es', name: 'Spanish' },
  { code: 'ru', name: 'Russian' }
];

const VOICES = [
  { id: 'Fenrir', name: 'Fenrir (Bass)' },
  { id: 'Kore', name: 'Kore (Balanced)' },
  { id: 'Puck', name: 'Puck (Light)' },
  { id: 'Charon', name: 'Charon (Deep)' },
  { id: 'Zephyr', name: 'Zephyr (Crisp)' }
];

const TONES = [
  { id: 'Neutral', label: 'NEUTRAL' },
  { id: 'Formal', label: 'FORMAL' },
  { id: 'Casual', label: 'CASUAL' },
  { id: 'Urgent', label: 'URGENT' },
  { id: 'Friendly', label: 'FRIENDLY' }
];

// Live API Encoding/Decoding Helpers
const encode = (bytes: Uint8Array) => {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
};

const decode = (base64: string) => {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) bytes[i] = binaryString.charCodeAt(i);
  return bytes;
};

const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> => {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
};

const Translator: React.FC = () => {
  const [targetLang, setTargetLang] = useState('English');
  const [mode, setMode] = useState<'audio' | 'text'>('audio');
  const [inputText, setInputText] = useState('');
  const [result, setResult] = useState<TranslationResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  
  // Settings
  const [voice, setVoice] = useState('Fenrir');
  const [tone, setTone] = useState('Neutral');
  const [rate, setRate] = useState(1.0);
  const [autoPlay, setAutoPlay] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [isLive, setIsLive] = useState(false);

  // Live State
  const [liveTranscription, setLiveTranscription] = useState<{original: string, translated: string}[]>([]);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const liveSessionRef = useRef<any>(null);
  const [liveStatus, setLiveStatus] = useState<'idle' | 'connecting' | 'active'>('idle');
  const progressIntervalRef = useRef<number | null>(null);

  // Staged Audio
  const [pendingAudio, setPendingAudio] = useState<{ base64: string; mimeType: string; id: number } | null>(null);

  // Live Session Lifecycle
  useEffect(() => {
    if (isLive && mode === 'audio') {
      startLiveSession();
    } else {
      stopLiveSession();
    }
    return () => stopLiveSession();
  }, [isLive, mode, targetLang]);

  const startLiveSession = async () => {
    if (!process.env.API_KEY) return;
    setLiveStatus('connecting');
    playSound('start');

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    // Setup contexts
    inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
    outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

    const sessionPromise = ai.live.connect({
      model: 'gemini-2.5-flash-native-audio-preview-12-2025',
      callbacks: {
        onopen: () => {
          setLiveStatus('active');
          if (inputAudioContextRef.current && inputAudioContextRef.current.state !== 'closed') {
              const source = inputAudioContextRef.current.createMediaStreamSource(stream);
              const scriptProcessor = inputAudioContextRef.current.createScriptProcessor(4096, 1, 1);
              scriptProcessor.onaudioprocess = (e) => {
                const inputData = e.inputBuffer.getChannelData(0);
                const l = inputData.length;
                const int16 = new Int16Array(l);
                for (let i = 0; i < l; i++) int16[i] = inputData[i] * 32768;
                const pcmBlob = {
                  data: encode(new Uint8Array(int16.buffer)),
                  mimeType: 'audio/pcm;rate=16000',
                };
                sessionPromise.then(session => session.sendRealtimeInput({ media: pcmBlob }));
              };
              source.connect(scriptProcessor);
              scriptProcessor.connect(inputAudioContextRef.current.destination);
          }
        },
        onmessage: async (message: LiveServerMessage) => {
          // Handle Audio
          const audioBase64 = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
          if (audioBase64 && outputAudioContextRef.current && outputAudioContextRef.current.state !== 'closed') {
            const ctx = outputAudioContextRef.current;
            nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
            const buffer = await decodeAudioData(decode(audioBase64), ctx, 24000, 1);
            const source = ctx.createBufferSource();
            source.buffer = buffer;
            source.playbackRate.value = rate;
            source.connect(ctx.destination);
            source.start(nextStartTimeRef.current);
            nextStartTimeRef.current += buffer.duration / rate;
            sourcesRef.current.add(source);
            source.onended = () => sourcesRef.current.delete(source);
          }

          // Handle Transcriptions
          if (message.serverContent?.inputTranscription) {
            const text = message.serverContent.inputTranscription.text;
            setLiveTranscription(prev => {
              const last = prev[prev.length - 1];
              if (last && !last.translated) {
                return [...prev.slice(0, -1), { ...last, original: (last.original + " " + text).trim() }];
              }
              return [...prev, { original: text, translated: "" }];
            });
          }
          if (message.serverContent?.outputTranscription) {
            const text = message.serverContent.outputTranscription.text;
            setLiveTranscription(prev => {
              const last = prev[prev.length - 1];
              if (last) {
                return [...prev.slice(0, -1), { ...last, translated: (last.translated + " " + text).trim() }];
              }
              return prev;
            });
          }
          
          if (message.serverContent?.interrupted) {
            sourcesRef.current.forEach(s => s.stop());
            sourcesRef.current.clear();
            nextStartTimeRef.current = 0;
          }
        },
        onerror: (e) => console.error("Live Error", e),
        onclose: () => setLiveStatus('idle'),
      },
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } } },
        inputAudioTranscription: {},
        outputAudioTranscription: {},
        systemInstruction: `You are a real-time speech translator. Translate everything the user says accurately into ${targetLang} with a ${tone} tone. Keep your responses limited strictly to the translation. Do not explain things unless asked.`
      }
    });

    liveSessionRef.current = await sessionPromise;
  };

  const stopLiveSession = () => {
    if (liveSessionRef.current) {
      liveSessionRef.current.close();
      liveSessionRef.current = null;
    }
    // Safe closing of contexts
    if (inputAudioContextRef.current && inputAudioContextRef.current.state !== 'closed') {
        inputAudioContextRef.current.close().catch(console.error);
    }
    if (outputAudioContextRef.current && outputAudioContextRef.current.state !== 'closed') {
        outputAudioContextRef.current.close().catch(console.error);
    }
    setLiveStatus('idle');
    playSound('stop');
  };

  const handleAudioReady = (base64: string, mimeType: string) => {
    setPendingAudio({ base64, mimeType, id: Date.now() });
    setResult(null); 
    setProgress(0);
    playSound('success');
  };

  const handleSpeak = async (text: string, id: string) => {
    if (!text || speakingId) return;
    setSpeakingId(id);
    try {
      const audioData = await synthesizeSpeech(text, voice, rate);
      await playRawAudio(audioData, rate);
    } catch (e) {
      console.error(e);
    } finally {
      setSpeakingId(null);
    }
  };

  const handleExecute = async () => {
    setLoading(true);
    setProgress(0);
    
    // Progress interval
    progressIntervalRef.current = window.setInterval(() => {
      setProgress(prev => {
        if (prev < 40) return prev + 3;
        if (prev < 80) return prev + 1.5;
        if (prev < 95) return prev + 0.5;
        return prev;
      });
    }, 120);

    try {
      let data: TranslationResult;
      if (mode === 'audio' && pendingAudio) {
        data = await translateAudio(pendingAudio.base64, pendingAudio.mimeType, targetLang, tone);
      } else if (mode === 'text' && inputText.trim()) {
        data = await translateText(inputText, targetLang, tone);
      } else {
        setLoading(false);
        if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
        return;
      }

      if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
      setProgress(100);

      setTimeout(() => {
        setResult(data);
        setLoading(false);
        saveToHistory({
          type: 'TRANSLATOR',
          summary: `${data.detectedLanguage} >> ${data.targetLanguage}`,
          detail: data.originalText.substring(0, 100)
        });
        playSound('success');
        
        if (autoPlay && data.translatedText) {
          handleSpeak(data.translatedText, 'output');
        }
      }, 400);

    } catch (error) {
      console.error(error);
      if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
      setLoading(false);
    }
  };

  const clearSignal = () => {
    setPendingAudio(null);
    setInputText('');
    setResult(null);
    setLiveTranscription([]);
    setProgress(0);
    playSound('stop');
  };

  const hasPendingSignal = (mode === 'audio' && pendingAudio) || (mode === 'text' && inputText.trim().length > 0);

  const getProgressLabel = (p: number) => {
    if (p < 30) return "ESTABLISHING_NEURAL_BRIDGE";
    if (p < 60) return "DECODING_LINGUISTIC_VECTORS";
    if (p < 90) return "SYNTHESIZING_TARGET_SYNTAX";
    return "BRIDGE_ESTABLISHED";
  };

  return (
    <div className="max-w-5xl mx-auto space-y-12 animate-slide-up">
      <div className="flex flex-col md:flex-row items-center justify-between gap-6 border-l-2 border-[#00ff41] pl-6 py-2">
        <div>
           <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#00ff41]/10 border border-[#00ff41]/20 rounded text-[10px] font-mono font-bold text-[#00ff41] uppercase tracking-[0.3em] mb-4">
            <Globe size={12} /> NEURAL_BRIDGE_LAYER_v5
          </div>
          <h1 className="text-6xl font-bold text-white font-display uppercase italic tracking-tighter">TRANSLATOR<span className="text-[#00ff41]">.CORE</span></h1>
        </div>

        <div className="flex flex-wrap items-center justify-center md:justify-end gap-4">
          <button 
            onClick={() => setIsLive(!isLive)}
            className={`px-6 py-2.5 rounded-sm border font-mono text-[10px] font-bold uppercase tracking-[0.3em] transition-all flex items-center gap-3 ${
              isLive ? 'bg-red-500/10 text-red-500 border-red-500/50 shadow-[0_0_20px_rgba(239,68,68,0.2)] animate-pulse' : 'bg-white/5 text-gray-500 border-white/10 hover:border-[#00ff41]/50 hover:text-white'
            }`}
          >
            <Radio size={14} className={isLive ? 'animate-pulse' : ''} /> {isLive ? 'LIVE_ACTIVE' : 'START_LIVE'}
          </button>
          
          <div className="flex bg-black border border-white/10 p-1.5 rounded-sm">
             <button onClick={() => { setMode('audio'); clearSignal(); }} className={`px-6 py-2 text-[10px] font-mono font-bold rounded transition-all flex items-center gap-2 uppercase tracking-widest ${mode === 'audio' ? 'bg-[#00ff41] text-black' : 'text-gray-600 hover:text-white'}`}>
               <Volume2 size={14} /> AUDIO
             </button>
             <button onClick={() => { setMode('text'); clearSignal(); }} className={`px-6 py-2 text-[10px] font-mono font-bold rounded transition-all flex items-center gap-2 uppercase tracking-widest ${mode === 'text' ? 'bg-[#00ff41] text-black' : 'text-gray-600 hover:text-white'}`}>
               <Type size={14} /> TEXT
             </button>
          </div>

          <div className="flex gap-2">
            <button 
              onClick={() => setAutoPlay(!autoPlay)}
              className={`p-3 rounded border transition-all ${autoPlay ? 'bg-[#00ff41]/20 text-[#00ff41] border-[#00ff41]/50' : 'bg-black border-white/10 text-gray-500 hover:text-white'}`}
              title="AUTO_PLAY_AUDIO"
            >
              <Ear size={20} />
            </button>

            <button onClick={() => setShowSettings(!showSettings)} className={`p-3 rounded border transition-all ${showSettings ? 'bg-[#00ff41]/20 text-[#00ff41] border-[#00ff41]/50' : 'bg-black border-white/10 text-gray-500 hover:text-white'}`}>
              <Settings size={20} />
            </button>
          </div>
        </div>
      </div>

      {showSettings && (
        <div className="glass-panel p-10 rounded-sm border-[#00ff41]/30 bg-black grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 animate-slide-up relative">
          <div className="space-y-6">
            <h3 className="text-[10px] font-mono font-bold text-[#00ff41] uppercase tracking-[0.4em] flex items-center gap-2"><User size={14} /> SYNTH_PROFILE</h3>
            <div className="grid grid-cols-2 gap-3">
              {VOICES.map(v => (
                <button key={v.id} onClick={() => setVoice(v.id)} className={`px-4 py-3 text-[10px] font-mono font-bold rounded border transition-all ${voice === v.id ? 'bg-[#00ff41] text-black border-[#00ff41]' : 'bg-[#050505] text-gray-600 border-white/5 hover:text-white'}`}>{v.name.split(' ')[0]}</button>
              ))}
            </div>
          </div>
          <div className="space-y-6">
            <h3 className="text-[10px] font-mono font-bold text-[#00ff41] uppercase tracking-[0.4em] flex items-center gap-2"><Sparkles size={14} /> EMOTIVE_TONE</h3>
            <div className="grid grid-cols-2 gap-3">
              {TONES.map(t => (
                <button key={t.id} onClick={() => setTone(t.id)} className={`px-4 py-3 text-[10px] font-mono font-bold rounded border transition-all ${tone === t.id ? 'bg-[#00ff41] text-black border-[#00ff41]' : 'bg-[#050505] text-gray-600 border-white/5 hover:text-white'}`}>{t.label}</button>
              ))}
            </div>
          </div>
          <div className="space-y-6">
            <h3 className="text-[10px] font-mono font-bold text-[#00ff41] uppercase tracking-[0.4em] flex items-center gap-2"><Terminal size={14} /> MODULATION</h3>
            <div className="space-y-4 pt-4">
              <div className="flex justify-between text-[10px] font-mono text-gray-600 uppercase tracking-widest">
                <span>BITRATE_SPEED</span><span className="text-[#00ff41] font-bold">{rate.toFixed(2)}x</span>
              </div>
              <input type="range" min="0.5" max="2.0" step="0.1" value={rate} onChange={(e) => setRate(parseFloat(e.target.value))} className="w-full h-1 bg-white/5 rounded-lg appearance-none cursor-pointer accent-[#00ff41]" />
            </div>
          </div>
        </div>
      )}

      {loading && (
        <div className="glass-panel p-12 rounded-sm border-[#00ff41]/30 bg-black flex flex-col items-center justify-center space-y-8 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-white/5">
             <div 
               className="h-full bg-[#00ff41] transition-all duration-300 shadow-[0_0_15px_#00ff41]" 
               style={{ width: `${progress}%` }}
             />
          </div>
          
          <div className="relative">
            <div className="w-24 h-24 border-2 border-[#00ff41]/20 rounded-full flex items-center justify-center animate-spin-slow">
              <Binary size={40} className="text-[#00ff41] animate-pulse" />
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
               <span className="text-[10px] font-mono font-bold text-white">{Math.floor(progress)}%</span>
            </div>
          </div>

          <div className="text-center space-y-3">
            <h3 className="text-xs font-mono font-bold text-[#00ff41] tracking-[0.5em] uppercase animate-pulse">
              {getProgressLabel(progress)}
            </h3>
            <p className="text-[9px] font-mono text-gray-600 uppercase tracking-widest">
              BRIDGING_LINGUISTIC_VECTORS... STANDBY
            </p>
          </div>
        </div>
      )}

      {isLive && mode === 'audio' ? (
        <div className="space-y-8 animate-slide-up">
          <div className="glass-panel p-10 rounded-sm border-[#00ff41]/20 bg-black min-h-[300px] flex flex-col relative overflow-hidden">
             <div className="absolute top-0 right-0 p-4 flex gap-2">
                <div className={`w-2 h-2 rounded-full ${liveStatus === 'active' ? 'bg-red-500 animate-pulse' : 'bg-gray-800'}`}></div>
                <span className="text-[9px] font-mono text-gray-500 uppercase tracking-widest">{liveStatus}</span>
             </div>
             
             <div className="flex-grow space-y-6 overflow-y-auto max-h-[400px] pr-4 custom-scrollbar">
                {liveTranscription.length === 0 && (
                   <div className="h-full flex flex-col items-center justify-center text-gray-800 font-mono text-[10px] uppercase tracking-[0.3em] gap-4 py-12">
                      <Mic size={32} className="animate-pulse" />
                      Awaiting Neural Signal Input...
                   </div>
                )}
                {liveTranscription.map((entry, i) => (
                  <div key={i} className="space-y-3 animate-slide-up border-l-2 border-white/5 pl-6 py-2 hover:border-[#00ff41]/30 transition-all group">
                    <div className="flex items-center gap-3">
                      <span className="text-[8px] font-mono text-gray-700 uppercase font-bold tracking-[0.2em]">ORIGINAL:</span>
                      <p className="text-gray-400 text-[11px] font-mono italic">{entry.original}</p>
                    </div>
                    {entry.translated && (
                      <div className="flex items-start gap-3">
                        <span className="text-[8px] font-mono text-[#00ff41] uppercase font-bold tracking-[0.2em]">BRIDGE:</span>
                        <p className="text-white text-[13px] font-mono tracking-tight font-medium">{entry.translated}</p>
                      </div>
                    )}
                  </div>
                ))}
             </div>
             
             <div className="mt-8 border-t border-white/5 pt-6 flex justify-between items-center">
                <div className="flex items-center gap-4">
                  <Activity size={16} className="text-[#00ff41] animate-pulse" />
                  <span className="text-[10px] font-mono text-gray-600 uppercase tracking-[0.4em]">Signal_Live // Stream_01</span>
                </div>
                <button onClick={clearSignal} className="text-[9px] font-mono text-gray-700 hover:text-red-500 uppercase tracking-widest transition-colors flex items-center gap-2">
                   <RotateCcw size={12} /> Clear_Feed
                </button>
             </div>
          </div>
        </div>
      ) : (
        <div className={`space-y-10 ${loading ? 'opacity-20 pointer-events-none' : ''}`}>
          <div className="glass-panel p-8 rounded-sm border-white/10 bg-black flex flex-col md:flex-row items-center justify-center gap-8 shadow-inner">
            <div className="flex items-center gap-4 text-gray-700 font-mono text-[10px] uppercase tracking-[0.3em]"><div className="w-1.5 h-1.5 bg-[#00ff41]/20 rounded-full"></div>AUTO_DETECT_INPUT</div>
            <div className="text-[#00ff41]/30"><ArrowRightLeft size={20} /></div>
            <div className="flex items-center gap-6 bg-[#050505] border border-white/10 p-2 pl-6 rounded group hover:border-[#00ff41]/30 transition-all">
              <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest font-bold">TARGET_CHANNEL:</span>
              <select value={targetLang} onChange={(e) => setTargetLang(e.target.value)} className="bg-black border border-white/10 text-[#00ff41] py-2.5 px-8 rounded focus:outline-none text-xs font-mono font-bold appearance-none cursor-pointer uppercase tracking-widest hover:border-[#00ff41]/50 transition-all">
                {LANGUAGES.map(lang => (
                  <option key={lang.code} value={lang.name} className="bg-black text-[#00ff41]">{lang.name}</option>
                ))}
              </select>
            </div>
          </div>

          {mode === 'audio' ? (
            <AudioInput onAudioReady={handleAudioReady} isProcessing={loading} />
          ) : (
            <div className="glass-panel p-10 rounded-sm border-white/10 bg-black space-y-6 relative">
               <div className="absolute top-0 right-0 p-4"><MessageSquare size={32} className="text-[#00ff41]/5" /></div>
              <h3 className="text-[10px] font-mono font-bold text-[#00ff41] uppercase tracking-[0.4em] flex items-center gap-2"><Terminal size={14} /> TEXT_SIGNAL_BUFFER</h3>
              <textarea value={inputText} onChange={(e) => { setInputText(e.target.value); setResult(null); }} placeholder="ENTER_TEXT_FOR_NEURAL_PROCESSING_LINK..." className="w-full bg-[#050505] border border-white/10 rounded p-8 text-sm font-mono text-white focus:outline-none focus:border-[#00ff41]/50 min-h-[180px] resize-none tracking-tight shadow-inner" />
            </div>
          )}

          {hasPendingSignal && !loading && (
            <div className="flex flex-col md:flex-row gap-6 animate-slide-up">
               <button onClick={clearSignal} className="px-10 py-5 border border-white/10 text-gray-500 font-mono text-[10px] font-bold uppercase tracking-[0.3em] hover:bg-white/5 rounded-sm flex items-center justify-center gap-2 transition-all"><RotateCcw size={14} /> PURGE</button>
               <button onClick={handleExecute} className="flex-grow py-5 bg-[#00ff41] text-black font-mono font-bold text-xs tracking-[0.4em] rounded-sm shadow-[0_0_30px_rgba(0,255,65,0.15)] flex items-center justify-center gap-5 group hover:bg-[#00dd3a] transition-all"><Zap size={20} fill="black" /> {result ? 'RE-PROCESS_SIGNAL' : 'INITIATE_BRIDGE_DECODE'}<Play size={16} fill="black" /></button>
            </div>
          )}
        </div>
      )}

      {result && !isLive && !loading && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pb-24 animate-slide-up">
          <TranslationCard 
            title="INPUT_ORIGIN" 
            lang={result.detectedLanguage || 'AUTO_DETECT'} 
            text={result.originalText} 
            accent="gray" 
            onSpeak={() => handleSpeak(result.originalText, 'input')}
            isSpeaking={speakingId === 'input'}
          />
          <TranslationCard 
            title="OUTPUT_BRIDGE" 
            lang={`${result.targetLanguage} // ${tone.toUpperCase()}`} 
            text={result.translatedText} 
            accent="green" 
            onSpeak={() => handleSpeak(result.translatedText, 'output')} 
            isSpeaking={speakingId === 'output'} 
          />
        </div>
      )}
    </div>
  );
};

const TranslationCard: React.FC<{ title: string, lang: string, text: string, accent: 'gray' | 'green', onSpeak?: () => void, isSpeaking?: boolean }> = ({ title, lang, text, accent, onSpeak, isSpeaking }) => {
  const accentStyle = accent === 'green' ? 'text-[#00ff41] border-[#00ff41]/40 bg-[#00ff41]/5 shadow-[0_0_20px_rgba(0,255,65,0.05)]' : 'text-gray-500 border-gray-800 bg-black/40';
  return (
    <div className={`glass-panel p-10 rounded-sm relative group border-t-2 transition-all ${accentStyle}`}>
      <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 opacity-20"></div>
      <div className="flex justify-between items-center mb-8">
        <div>
          <p className="text-[10px] font-mono text-gray-700 uppercase tracking-[0.3em] mb-2 font-bold">{title}</p>
          <div className="flex items-center gap-3">
            <h4 className={`text-xs font-bold uppercase tracking-[0.2em] font-mono ${accent === 'green' ? 'text-[#00ff41]' : 'text-white'}`}>{lang}</h4>
          </div>
        </div>
        {onSpeak && (
          <button onClick={onSpeak} disabled={isSpeaking} className="w-14 h-14 rounded-full bg-[#00ff41]/10 hover:bg-[#00ff41]/20 text-[#00ff41] border border-[#00ff41]/30 flex items-center justify-center transition-all disabled:opacity-50 shadow-[0_0_20px_rgba(0,255,65,0.15)]">
            {isSpeaking ? <Loader2 size={24} className="animate-spin" /> : <Volume2 size={24} />}
          </button>
        )}
      </div>
      <div className="bg-[#050505] p-8 rounded-sm border border-white/5 min-h-[160px] shadow-inner relative">
        <p className="text-gray-300 text-sm leading-relaxed font-mono tracking-tighter whitespace-pre-wrap">{text}</p>
      </div>
    </div>
  );
};

export default Translator;