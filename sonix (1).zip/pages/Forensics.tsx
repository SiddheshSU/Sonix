import React, { useState, useEffect, useRef } from 'react';
import AudioInput from '../components/AudioInput';
import { analyzeAudioForensics } from '../services/geminiService';
import { AnalysisResult } from '../types';
import { ShieldAlert, Fingerprint, Search, ShieldCheck, TrendingUp, Languages, Info, Terminal, Zap, Play, RotateCcw, Cpu, Scan, Activity, Volume2, Shield, AlertTriangle, InfoIcon, Target, Loader2, Binary } from 'lucide-react';
import { playSound } from '../utils/soundEffects';
import { saveToHistory } from '../utils/historyStore';

const Forensics: React.FC = () => {
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  
  const [pendingSignal, setPendingSignal] = useState<{ base64: string; mimeType: string; timestamp: number } | null>(null);
  const progressIntervalRef = useRef<number | null>(null);

  const handleAudioReady = (base64: string, mimeType: string) => {
    setPendingSignal({ base64, mimeType, timestamp: Date.now() });
    setResult(null); 
    setProgress(0);
    playSound('success');
  };

  const executeAnalysis = async () => {
    if (!pendingSignal) return;
    setLoading(true);
    setError(null);
    setProgress(0);

    // Simulate forensic execution progress
    progressIntervalRef.current = window.setInterval(() => {
      setProgress(prev => {
        if (prev < 30) return prev + 2;
        if (prev < 70) return prev + 1;
        if (prev < 95) return prev + 0.5;
        return prev;
      });
    }, 150);

    try {
      const data = await analyzeAudioForensics(pendingSignal.base64, pendingSignal.mimeType);
      
      // Complete the progress
      if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
      setProgress(100);
      
      setTimeout(() => {
        setResult(data);
        setLoading(false);
        saveToHistory({
          type: 'DETECTOR',
          summary: data.verdict || 'SCAM_SCAN_COMPLETE',
          detail: `Safety: ${data.safetyPercentage}% // Risk: ${data.riskLevel}`
        });
        playSound('success');
      }, 500);

    } catch (err) {
      if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
      setError("DETECTION_INTERRUPT: Scam analysis kernel failed.");
      playSound('error');
      setLoading(false);
    }
  };

  const resetBuffer = () => {
    setPendingSignal(null);
    setResult(null);
    setError(null);
    setProgress(0);
    playSound('stop');
  };

  const getProgressLabel = (p: number) => {
    if (p < 20) return "INITIALIZING_NEURAL_BUS";
    if (p < 40) return "DECRYPTING_SPECTRAL_ARRAYS";
    if (p < 60) return "PATTERN_MATCHING_FRAUD_MODELS";
    if (p < 80) return "CALCULATING_RISK_VECTORS";
    if (p < 95) return "FINALIZING_FORENSIC_MANIFEST";
    return "DECODE_COMPLETE";
  };

  return (
    <div className="max-w-6xl mx-auto space-y-12 animate-slide-up">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-l-2 border-[#00ff41] pl-6 py-2">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#00ff41]/10 border border-[#00ff41]/20 rounded text-[10px] font-mono font-bold text-[#00ff41] uppercase tracking-[0.2em] mb-4">
            <ShieldAlert size={12} /> FRAUD_INTERCEPT_KERNEL_v1
          </div>
          <h1 className="text-6xl font-bold text-white font-display uppercase italic tracking-tighter">SCAM_DETECTOR<span className="text-[#00ff41]">.X</span></h1>
          <p className="text-gray-600 text-[10px] font-mono mt-1 tracking-[0.3em] uppercase">
            SPOOF_VERIFICATION // MALICIOUS_INTENT_TRIAGE
          </p>
        </div>
        <div className="text-right hidden md:block">
           <p className="text-[10px] font-mono text-gray-700 uppercase tracking-widest">System Status</p>
           <p className="text-[10px] font-mono text-[#00ff41] font-bold uppercase">Ready for Signal Capture</p>
        </div>
      </div>

      <div className="space-y-8">
        <AudioInput onAudioReady={handleAudioReady} isProcessing={loading} />

        {loading && (
          <div className="glass-panel p-12 rounded-sm border-[#00ff41]/30 bg-black flex flex-col items-center justify-center space-y-8 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-white/5">
               <div 
                 className="h-full bg-[#00ff41] transition-all duration-300 shadow-[0_0_15px_#00ff41]" 
                 style={{ width: `${progress}%` }}
               />
            </div>
            
            <div className="relative">
              <div className="w-24 h-24 border-2 border-[#00ff41]/20 rounded-full flex items-center justify-center animate-spin-slow">
                <Binary size={40} className="text-[#00ff41] animate-pulse" />
              </div>
              <div className="absolute inset-0 flex items-center justify-center">
                 <span className="text-[10px] font-mono font-bold text-white">{Math.floor(progress)}%</span>
              </div>
            </div>

            <div className="text-center space-y-3">
              <h3 className="text-xs font-mono font-bold text-[#00ff41] tracking-[0.5em] uppercase animate-pulse">
                {getProgressLabel(progress)}
              </h3>
              <p className="text-[9px] font-mono text-gray-600 uppercase tracking-widest">
                EXECUTING_NEURAL_LAYER_ANALYSIS... STANDBY
              </p>
            </div>
            
            <div className="flex gap-2 w-full max-w-xs h-1 px-4">
              {Array.from({ length: 20 }).map((_, i) => (
                <div 
                  key={i} 
                  className={`flex-1 h-full rounded-full transition-all duration-500 ${
                    (progress / 100) * 20 > i ? 'bg-[#00ff41]' : 'bg-white/5'
                  }`}
                />
              ))}
            </div>
          </div>
        )}

        {pendingSignal && !loading && !result && (
          <div className="glass-panel p-8 border-[#00ff41]/30 bg-[#00ff41]/5 rounded relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-4 transition-all duration-500 animate-pulse shadow-[0_0_30px_rgba(0,255,65,0.08)]">
            <div className="absolute top-0 right-0 p-2">
               <Scan size={40} className="text-[#00ff41]/10" />
            </div>
            <div className="flex items-center gap-6 relative z-10">
              <div className="w-14 h-14 bg-[#00ff41] rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(0,255,65,0.4)]">
                <Zap size={24} className="text-black" />
              </div>
              <div>
                <p className="text-[#00ff41] font-mono font-bold text-xs tracking-widest uppercase">
                  Signal Buffer Staged // {new Date(pendingSignal.timestamp).toLocaleTimeString()}
                </p>
                <p className="text-gray-500 font-mono text-[9px] uppercase tracking-[0.2em] mt-1">
                  AWAITING_FRAUD_ANALYSIS_COMMAND...
                </p>
              </div>
            </div>
            <div className="flex gap-4 w-full md:w-auto relative z-10">
              <button 
                onClick={resetBuffer}
                className="flex-1 md:flex-none px-8 py-4 border border-white/10 text-gray-500 font-mono text-[10px] font-bold hover:bg-white/5 transition-all flex items-center justify-center gap-2 uppercase tracking-widest"
              >
                <RotateCcw size={14} /> PURGE
              </button>
              <button 
                onClick={executeAnalysis}
                className="flex-1 md:flex-none px-12 py-4 bg-[#00ff41] text-black font-mono text-xs font-bold tracking-[0.3em] hover:bg-[#00dd3a] transition-all shadow-xl shadow-[#00ff41]/20 flex items-center justify-center gap-2 uppercase"
              >
                <Play size={14} fill="black" /> INIT_SCAM_SCAN
              </button>
            </div>
          </div>
        )}
      </div>

      {error && (
        <div className="p-4 border border-red-500/30 bg-red-500/5 text-red-500 text-xs font-mono rounded-sm animate-pulse flex items-center gap-3">
          <ShieldAlert size={16} /> [CRITICAL_FAULT]: {error}
        </div>
      )}

      {result && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pb-24 animate-slide-up">
          
          <div className="lg:col-span-4 space-y-8">
             <div className="flex justify-between items-center px-4">
                <button 
                  onClick={resetBuffer}
                  className="text-[9px] font-mono font-bold text-gray-500 hover:text-white uppercase tracking-[0.2em] flex items-center gap-2"
                >
                  <RotateCcw size={12} /> SCAN_NEW_SIGNAL
                </button>
                <span className="text-[9px] font-mono text-[#00ff41] font-bold tracking-[0.4em]">DECODE_SUCCESS // 100%</span>
             </div>

            <ResultCard 
              label="AUTH_VERDICT"
              title={result.verdict || 'UNCERTAIN'}
              value={`${result.confidence || 0}% PROBABILITY`}
              status={result.verdict === 'HUMAN VERIFIED' ? 'success' : result.verdict === 'AI GENERATED' ? 'danger' : 'warning'}
              icon={<Fingerprint size={28} />}
            />
            
            <div className={`glass-panel p-8 rounded-sm border-l-4 relative group transition-all hover:scale-[1.02] ${
              result.safetyPercentage > 70 ? 'text-[#00ff41] border-[#00ff41]/40 bg-[#00ff41]/5' : 
              result.safetyPercentage > 40 ? 'text-yellow-500 border-yellow-500/40 bg-yellow-500/5' : 
              'text-red-500 border-red-500/40 bg-red-500/5'
            }`}>
              <div className="flex justify-between items-start mb-6">
                <p className="text-[9px] font-mono font-bold text-gray-700 uppercase tracking-[0.4em]">THREAT_INDEX</p>
                <div className="flex flex-col items-end">
                  <Shield size={28} className="opacity-80" />
                  {result.safetyAccuracy !== undefined && (
                    <div className="mt-2 px-2 py-0.5 bg-black/40 border border-white/10 rounded-sm flex items-center gap-1.5">
                      <Target size={10} className="text-[#00ff41]/60" />
                      <span className="text-[8px] font-mono font-bold text-white uppercase">Acc: {result.safetyAccuracy}%</span>
                    </div>
                  )}
                </div>
              </div>
              <div className="flex items-baseline gap-2 mb-4">
                <h4 className="text-4xl font-bold font-display italic tracking-tighter leading-none">{result.safetyPercentage}%</h4>
                <span className="text-[10px] font-mono uppercase font-bold tracking-widest opacity-60">SAFETY_SCORE</span>
              </div>
              
              <div className="grid grid-cols-2 gap-4 border-t border-white/5 pt-6 mt-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-gray-500 text-[9px] font-mono uppercase font-bold">
                    <Volume2 size={12} /> LEVEL
                  </div>
                  <p className="text-white text-[10px] font-mono uppercase">{result.voiceAnalysis?.level || 'N/A'}</p>
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-gray-500 text-[9px] font-mono uppercase font-bold">
                    <Activity size={12} /> QUALITY
                  </div>
                  <p className="text-white text-[10px] font-mono uppercase">{result.voiceAnalysis?.quality || 'N/A'}</p>
                </div>
              </div>

              <div className="mt-6">
                <div className="w-full bg-black/40 h-1.5 rounded-full overflow-hidden border border-white/5">
                  <div 
                    className={`h-full transition-all duration-1000 ${
                      result.safetyPercentage > 70 ? 'bg-[#00ff41]' : 
                      result.safetyPercentage > 40 ? 'bg-yellow-500' : 'bg-red-500'
                    }`} 
                    style={{ width: `${result.safetyPercentage}%` }}
                  ></div>
                </div>
              </div>

              <p className="text-[9px] text-gray-500 font-mono leading-relaxed mt-4 uppercase tracking-tighter italic">
                {result.messageDecoding?.riskReasoning}
              </p>
            </div>
          </div>

          <div className="lg:col-span-8 space-y-8">
            {/* Actionable Advice Panel */}
            {result.scamAdvice && (
              <div className={`glass-panel p-8 rounded-sm border-2 animate-pulse ${result.safetyPercentage < 50 ? 'border-red-500/50 bg-red-500/5' : 'border-[#00ff41]/30 bg-[#00ff41]/5'}`}>
                <div className="flex items-center gap-4 mb-6">
                  <div className={`p-3 rounded-full ${result.safetyPercentage < 50 ? 'bg-red-500/20 text-red-500' : 'bg-[#00ff41]/20 text-[#00ff41]'}`}>
                    {result.safetyPercentage < 50 ? <AlertTriangle size={24} /> : <InfoIcon size={24} />}
                  </div>
                  <div>
                    <h3 className={`text-xs font-bold font-mono tracking-[0.3em] uppercase ${result.safetyPercentage < 50 ? 'text-red-500' : 'text-[#00ff41]'}`}>TACTICAL_ADVISORY_REPORT</h3>
                    <p className="text-gray-500 text-[9px] font-mono uppercase tracking-widest mt-1">Recommended Response Protocol</p>
                  </div>
                </div>
                <div className="bg-black/50 p-6 rounded border border-white/5 font-mono text-[11px] text-white leading-relaxed tracking-tight italic border-l-4 border-l-white/20">
                  {result.scamAdvice}
                </div>
              </div>
            )}

            <div className="glass-panel rounded-sm border-white/10 overflow-hidden relative">
              <div className="px-8 py-5 border-b border-white/10 bg-white/5 flex items-center justify-between">
                <h3 className="text-[10px] font-mono font-bold text-white uppercase tracking-[0.4em] flex items-center gap-2">
                  <Terminal size={14} className="text-[#00ff41]" /> DECODE_MANIFEST
                </h3>
              </div>

              <div className="p-10 grid grid-cols-1 md:grid-cols-2 gap-12">
                <div className="space-y-8">
                  <DecodeItem icon={<Languages size={20} className="text-[#00ff41]" />} label="ORIGIN_LANG" value={result.messageDecoding?.language || 'UNDEFINED'} />
                  <DecodeItem icon={<Search size={20} className="text-[#00ff41]" />} label="SCAM_PATTERN" value={result.fraudType || 'NO_SPECIFIC_PATTERN'} />
                  <DecodeItem icon={<Cpu size={20} className="text-[#00ff41]" />} label="FUNCTION" value={result.messageDecoding?.extractedFunction || 'N/A'} />
                </div>

                <div className="space-y-8">
                   <div className="space-y-3">
                      <p className="text-[10px] text-gray-700 font-mono uppercase tracking-[0.3em] font-bold">SIGNAL_FLAGS</p>
                      <div className="flex flex-wrap gap-2">
                        {result.messageDecoding?.keyWording?.map((word, i) => (
                          <span key={i} className="px-3 py-1.5 bg-white/5 border border-white/10 text-white text-[9px] font-mono font-bold uppercase tracking-widest rounded-sm">
                            {word}
                          </span>
                        ))}
                      </div>
                   </div>
                   
                   <div className="space-y-4">
                      <p className="text-[10px] text-gray-700 font-mono uppercase tracking-[0.3em] font-bold">KERNEL_LOGS</p>
                      <ul className="space-y-3">
                        {result.details?.map((d, i) => (
                          <li key={i} className="text-[11px] text-gray-400 font-mono flex gap-3">
                            <span className="text-[#00ff41] font-bold">{i+1}:</span> {d}
                          </li>
                        ))}
                      </ul>
                   </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      )}
    </div>
  );
};

const ResultCard: React.FC<{ label: string, title: string, value: string, icon: React.ReactNode, status: 'success' | 'warning' | 'danger' }> = ({ label, title, value, icon, status }) => {
  const colors = {
    success: 'text-[#00ff41] border-[#00ff41]/40 bg-[#00ff41]/5 shadow-[0_0_20px_rgba(0,255,65,0.05)]',
    warning: 'text-yellow-500 border-yellow-500/40 bg-yellow-500/5',
    danger: 'text-red-500 border-red-500/40 bg-red-500/5'
  };

  return (
    <div className={`glass-panel p-8 rounded-sm border-l-4 relative group transition-all hover:scale-[1.02] ${colors[status]}`}>
      <div className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 opacity-30"></div>
      <div className="flex justify-between items-start mb-6">
        <p className="text-[9px] font-mono font-bold text-gray-700 uppercase tracking-[0.4em]">{label}</p>
        <div className="opacity-80">{icon}</div>
      </div>
      <h4 className="text-2xl font-bold font-display uppercase italic tracking-tighter leading-none mb-3">{title}</h4>
      <p className="text-[10px] text-gray-500 font-mono font-medium leading-relaxed tracking-tight uppercase border-t border-white/5 pt-3">{value}</p>
    </div>
  );
};

const DecodeItem: React.FC<{ icon: React.ReactNode, label: string, value: string }> = ({ icon, label, value }) => (
  <div className="flex items-start gap-5 group">
    <div className="mt-1 p-2 bg-white/5 rounded border border-white/5 group-hover:border-[#00ff41]/50 transition-all">{icon}</div>
    <div>
      <p className="text-[9px] text-gray-700 font-mono uppercase tracking-[0.3em] font-bold mb-1">{label}</p>
      <p className="text-xs text-white font-mono tracking-tight uppercase">{value}</p>
    </div>
  </div>
);

export default Forensics;