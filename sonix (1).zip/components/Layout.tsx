import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { ShieldCheck, Globe, Activity, Zap, Terminal, Clock, Calendar, Crosshair, MapPin } from 'lucide-react';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [time, setTime] = useState(new Date());
  const [location, setLocation] = useState<{ lat: string; lng: string } | null>(null);
  const [locStatus, setLocStatus] = useState<'ACQUIRING' | 'LOCKED' | 'OFFLINE'>('ACQUIRING');

  useEffect(() => {
    // Clock Timer
    const timer = setInterval(() => setTime(new Date()), 1000);

    // Geolocation
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude.toFixed(4),
            lng: position.coords.longitude.toFixed(4)
          });
          setLocStatus('LOCKED');
        },
        () => {
          setLocStatus('OFFLINE');
        }
      );
    } else {
      setLocStatus('OFFLINE');
    }

    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-GB', { hour12: false }); // 24h format
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).toUpperCase().replace(/ /g, '.');
  };

  return (
    <div className="min-h-screen bg-[#000000] flex flex-col relative">
      <div className="fixed inset-0 cyber-grid pointer-events-none"></div>
      
      <nav className="z-40 border-b border-[#00ff41]/10 bg-black/95 backdrop-blur-xl sticky top-0">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          
          {/* Logo Section */}
          <div className="flex items-center space-x-3 shrink-0">
            <div className="w-8 h-8 bg-[#00ff41] rounded flex items-center justify-center shadow-lg shadow-[#00ff41]/20">
              <Zap className="w-5 h-5 text-black" fill="currentColor" />
            </div>
            <span className="text-xl font-bold tracking-tighter text-white font-display uppercase italic hidden sm:block">
              SONIX<span className="text-[#00ff41]"> // </span>VERTEX
            </span>
          </div>
          
          {/* Tactical HUD - Center (Hidden on small mobile) */}
          <div className="hidden lg:flex items-center gap-6 px-6 py-2 bg-white/5 border border-white/5 rounded-sm mx-4">
             <div className="flex items-center gap-3 border-r border-white/10 pr-6">
                <Clock size={12} className="text-[#00ff41]" />
                <div className="flex flex-col">
                  <span className="text-[8px] font-mono text-gray-500 font-bold tracking-widest leading-none mb-1">SYS_TIME</span>
                  <span className="text-[10px] font-mono text-white font-bold tracking-widest leading-none">{formatTime(time)}</span>
                </div>
             </div>
             
             <div className="flex items-center gap-3 border-r border-white/10 pr-6">
                <Calendar size={12} className="text-[#00ff41]" />
                <div className="flex flex-col">
                  <span className="text-[8px] font-mono text-gray-500 font-bold tracking-widest leading-none mb-1">DATE_LOG</span>
                  <span className="text-[10px] font-mono text-white font-bold tracking-widest leading-none">{formatDate(time)}</span>
                </div>
             </div>

             <div className="flex items-center gap-3">
                {locStatus === 'LOCKED' ? <Crosshair size={12} className="text-[#00ff41]" /> : <MapPin size={12} className="text-red-500" />}
                <div className="flex flex-col">
                  <span className="text-[8px] font-mono text-gray-500 font-bold tracking-widest leading-none mb-1">
                    {locStatus === 'LOCKED' ? 'GEO_LOCK' : 'SAT_LINK'}
                  </span>
                  <span className={`text-[10px] font-mono font-bold tracking-widest leading-none ${locStatus === 'LOCKED' ? 'text-white' : 'text-red-500/80'}`}>
                    {location ? `${location.lat} : ${location.lng}` : 'SIGNAL_LOST'}
                  </span>
                </div>
             </div>
          </div>

          {/* Navigation Links */}
          <div className="flex items-center space-x-1 sm:space-x-2 shrink-0">
            <NavItem to="/" icon={<Activity size={14} />} label="COMMAND" />
            <NavItem to="/forensics" icon={<ShieldCheck size={14} />} label="DETECTOR" />
            <NavItem to="/translator" icon={<Globe size={14} />} label="TRANSLATOR" />
          </div>
        </div>
      </nav>

      <main className="flex-grow z-10 relative container mx-auto px-6 py-10">
        {children}
      </main>

      <footer className="z-10 border-t border-white/5 bg-black py-4">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-2">
          <div className="text-[9px] font-mono text-gray-700 uppercase tracking-[0.2em] flex items-center gap-2">
            <Terminal size={10} /> VERTEX_OS // REVISION_X // ENCRYPTED_LINK
          </div>
          
          {/* Mobile Only Time Display */}
          <div className="lg:hidden flex items-center gap-3 text-[9px] font-mono text-gray-600">
             <span>{formatDate(time)}</span>
             <span className="text-[#00ff41]">{formatTime(time)}</span>
          </div>

          <div className="flex items-center gap-2 text-[9px] font-mono text-[#00ff41]/50 tracking-widest">
            <div className="w-1 h-1 bg-[#00ff41] rounded-full animate-pulse"></div>
            KERNEL_LIVE
          </div>
        </div>
      </footer>
    </div>
  );
};

const NavItem: React.FC<{ to: string, icon: React.ReactNode, label: string }> = ({ to, icon, label }) => (
  <NavLink 
    to={to} 
    className={({ isActive }) => 
      `flex items-center space-x-2 px-4 py-1.5 text-[10px] font-bold transition-all duration-300 rounded uppercase tracking-[0.2em] font-mono border ${
        isActive 
          ? 'bg-[#00ff41]/10 text-[#00ff41] border-[#00ff41]/40 shadow-[0_0_15px_rgba(0,255,65,0.15)]' 
          : 'text-gray-500 border-transparent hover:text-white hover:bg-white/5'
      }`
    }
  >
    {icon}
    <span className="hidden sm:inline">{label}</span>
  </NavLink>
);

export default Layout;