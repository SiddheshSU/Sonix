import React, { useState, useRef, useEffect } from 'react';
import { Mic, Upload, StopCircle, Activity, Waves, Terminal, Clock } from 'lucide-react';
import { AudioInputProps } from '../types';
import { playSound } from '../utils/soundEffects';

const AudioInput: React.FC<AudioInputProps> = ({ onAudioReady, isProcessing }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingMs, setRecordingMs] = useState(0);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);
  const startTimeRef = useRef<number>(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number>(0);

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      // Safe cleanup for AudioContext
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close().catch(console.error);
      }
    };
  }, []);

  const formatTime = (ms: number) => {
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    const centiseconds = Math.floor((ms % 1000) / 10);
    
    return {
      display: `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`,
      ms: String(centiseconds).padStart(2, '0')
    };
  };

  const drawWaveform = () => {
    if (!canvasRef.current || !analyserRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const analyser = analyserRef.current;
    if (!ctx) return;

    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    const draw = () => {
      animationFrameRef.current = requestAnimationFrame(draw);
      analyser.getByteFrequencyData(dataArray);

      ctx.fillStyle = 'rgba(5, 5, 5, 0.8)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const barWidth = (canvas.width / bufferLength) * 2;
      let x = 0;

      for (let i = 0; i < bufferLength; i++) {
        const barHeight = (dataArray[i] / 255) * (canvas.height * 0.8);
        const gradient = ctx.createLinearGradient(0, canvas.height / 2 - barHeight / 2, 0, canvas.height / 2 + barHeight / 2);
        gradient.addColorStop(0, 'rgba(0, 255, 65, 0.1)');
        gradient.addColorStop(0.5, 'rgba(0, 255, 65, 1)');
        gradient.addColorStop(1, 'rgba(0, 255, 65, 0.1)');

        ctx.fillStyle = gradient;
        const yPos = (canvas.height / 2) - (barHeight / 2);
        
        ctx.beginPath();
        if ((ctx as any).roundRect) {
          (ctx as any).roundRect(x, yPos, barWidth - 1, barHeight, 2);
        } else {
          ctx.rect(x, yPos, barWidth - 1, barHeight);
        }
        ctx.fill();

        if (dataArray[i] > 180) {
            ctx.shadowBlur = 10;
            ctx.shadowColor = '#00ff41';
        } else {
            ctx.shadowBlur = 0;
        }
        x += barWidth;
      }
    };

    draw();
  };

  const startRecording = async () => {
    try {
      playSound('start');
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      audioContextRef.current = audioCtx;
      const analyser = audioCtx.createAnalyser();
      
      analyser.fftSize = 256; 
      analyser.smoothingTimeConstant = 0.8;
      analyserRef.current = analyser;
      
      const source = audioCtx.createMediaStreamSource(stream);
      source.connect(analyser);
      drawWaveform();

      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = () => {
        playSound('stop');
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        processBlob(blob);
        stream.getTracks().forEach(track => track.stop());
        
        // Ensure we don't close an already closed context
        if (audioCtx.state !== 'closed') {
            audioCtx.close().catch(console.error);
        }
        
        cancelAnimationFrame(animationFrameRef.current);
      };

      mediaRecorder.start();
      setIsRecording(true);
      startTimeRef.current = Date.now();
      setRecordingMs(0);
      
      timerRef.current = window.setInterval(() => {
        setRecordingMs(Date.now() - startTimeRef.current);
      }, 50); // Higher frequency for centiseconds
    } catch (err) {
      playSound('error');
      alert("Microphone access denied.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) clearInterval(timerRef.current);
    }
  };

  const processBlob = (blob: Blob) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64Content = (reader.result as string).split(',')[1];
      onAudioReady(base64Content, blob.type || 'audio/mp3');
    };
    reader.readAsDataURL(blob);
  };

  const timeData = formatTime(recordingMs);

  return (
    <div className="w-full glass-panel rounded-lg border-[#00ff41]/20 p-8 bg-black shadow-[0_0_20px_rgba(0,255,65,0.02)]">
      <div className="flex flex-col lg:flex-row gap-8 items-center">
        
        <div className="flex-1 w-full space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-[10px] font-mono font-bold text-[#00ff41] uppercase tracking-[0.3em] flex items-center gap-2">
              <Terminal size={12} /> SIGNAL_ACQUISITION
            </h3>
            {isRecording && (
              <div className="flex items-center gap-1.5 px-2 py-0.5 bg-red-500/10 border border-red-500/30 rounded-sm">
                <div className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse"></div>
                <span className="text-red-500 font-mono text-[9px] font-bold tracking-widest uppercase">REC</span>
              </div>
            )}
          </div>
          
          {/* Main Visualizer Container */}
          <div className="h-32 bg-[#050505] border border-[#00ff41]/10 rounded flex shadow-inner group overflow-hidden">
             
             {/* Left: Waveform Visualization (Minimized Width - 33%) */}
             <div className="w-1/3 relative overflow-hidden bg-black/50 border-r border-[#00ff41]/10">
                {!isRecording && !isProcessing && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center z-10">
                      <div className="text-gray-800 text-[10px] font-mono tracking-widest uppercase flex flex-col items-center gap-2">
                        <Activity size={20} className="opacity-20" />
                        READY
                      </div>
                    </div>
                )}
                <canvas 
                  ref={canvasRef} 
                  width={300} 
                  height={128} 
                  className="absolute inset-0 w-full h-full opacity-90 transition-opacity duration-500" 
                />
                <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-transparent via-[#00ff41]/5 to-transparent h-[2px] w-full animate-scanline opacity-20"></div>
             </div>

             {/* Right: Dedicated Timer Section (Expanded) */}
             <div className="flex-1 flex flex-col items-center justify-center bg-black/40 backdrop-blur-sm p-4 transition-colors duration-300">
                {isRecording ? (
                    <div className="flex flex-col items-center animate-slide-up">
                        <div className="flex items-baseline gap-1">
                          <span className="text-4xl font-mono font-bold text-[#00ff41] tracking-tighter">
                            {timeData.display}
                          </span>
                          <span className="text-xl font-mono font-bold text-[#00ff41]/50">
                            .{timeData.ms}
                          </span>
                        </div>
                        <span className="text-[10px] font-mono text-[#00ff41]/40 uppercase tracking-[0.4em] animate-pulse mt-2">
                          CAPTURING_SIGNAL
                        </span>
                    </div>
                ) : (
                    <div className="flex flex-col items-center opacity-40">
                       <Clock size={24} className="text-gray-500 mb-2" />
                       <span className="text-sm font-mono text-gray-500 font-bold tracking-widest">
                         00:00.00
                       </span>
                    </div>
                )}
             </div>
          </div>

          <div className="flex gap-4">
            <button
              onClick={isRecording ? stopRecording : startRecording}
              disabled={isProcessing}
              className={`flex-1 py-4 rounded font-mono font-bold text-[11px] tracking-widest flex items-center justify-center gap-3 transition-all ${
                isRecording 
                  ? 'bg-red-500/10 text-red-500 border border-red-500/40' 
                  : 'bg-[#00ff41] text-black hover:bg-[#00dd3a] shadow-lg shadow-[#00ff41]/10'
              }`}
            >
              {isRecording ? <StopCircle size={18} /> : <Mic size={18} />}
              {isRecording ? 'HALT_CAPTURE' : 'EXECUTE_CAPTURE'}
            </button>
            
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isProcessing || isRecording}
              className="px-6 border border-white/5 hover:border-[#00ff41]/30 text-gray-600 hover:text-[#00ff41] transition-all rounded bg-white/5"
              title="UPLOAD_SIGNAL"
            >
              <Upload size={18} />
            </button>
          </div>
        </div>

        <input
          type="file"
          ref={fileInputRef}
          onChange={(e) => e.target.files?.[0] && processBlob(e.target.files[0])}
          accept="audio/*"
          className="hidden"
        />
      </div>
    </div>
  );
};

export default AudioInput;